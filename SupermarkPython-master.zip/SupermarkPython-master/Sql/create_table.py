import database

database = database.Database("supermarket.db")

database.create_table("products", {})
